//
//  BaseViewController.h
//  PopTiner
//
//  Created by zizhou wang on 2018/9/3.
//  Copyright © 2018年 zizhou wang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Util.h"

@interface BaseViewController : UIViewController

@end
