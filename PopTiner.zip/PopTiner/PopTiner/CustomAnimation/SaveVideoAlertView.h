//
//  SaveVideoAlertView.h
//  PopTiner
//
//  Created by Mac on 2018/9/13.
//  Copyright © 2018年 zizhou wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SaveVideoAlertView : UIView

- (void)startAnimation;
- (void)showAlertLabel:(NSString*)alertStr;

@end
