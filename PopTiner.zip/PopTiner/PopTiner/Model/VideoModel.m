//
//Created by ESJsonFormatForMac on 18/09/05.
//

#import "VideoModel.h"

@implementation VideoModel

@end

@implementation VideoDetails

@end


