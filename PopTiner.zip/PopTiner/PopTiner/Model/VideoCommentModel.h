//
//  VideoCommentModel.h
//  PopTiner
//
//  Created by Mac on 2018/9/14.
//  Copyright © 2018年 zizhou wang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoCommentModel : NSObject

@property (nonatomic, copy) NSString * imageName;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *commentContent;

@end
