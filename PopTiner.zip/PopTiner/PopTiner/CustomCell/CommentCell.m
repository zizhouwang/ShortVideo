//
//  CommentCell.m
//  PopTiner
//
//  Created by Mac on 2018/9/14.
//  Copyright © 2018年 zizhou wang. All rights reserved.
//

#import "CommentCell.h"

@implementation CommentCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
